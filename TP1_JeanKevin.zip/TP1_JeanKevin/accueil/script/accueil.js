const taskInput = document.getElementById("taskInput");
const addTaskBtn = document.getElementById("addTaskBtn");
const taskList = document.getElementById("taskList");

var task = "Task";
var i =0 ;

addTaskBtn.addEventListener("click", addTask);

// BOUTTON "AJOUTER"
function addTask() {
    const taskText = taskInput.value.trim();
    if (taskText !== "") {
        const listItem = document.createElement("li");
        listItem.textContent = taskText;
        taskList.appendChild(listItem);
        taskInput.value = "";

        const deleteBtn = document.createElement("button");
        deleteBtn.textContent = "Supprimer";
        listItem.appendChild(deleteBtn);
        deleteBtn.addEventListener("click", () => {
            listItem.remove();
        });
      
        listItem.addEventListener("click", () => {
            listItem.classList.toggle("completed");
        });

        listItem.addEventListener("dblclick", () => {
            const newText = prompt("Modifier la tâche :", listItem.textContent);
            if (newText !== null && newText !== "") {
                listItem.textContent = newText;
            }
            btDelete();
        });
    } else {
        alert("Veuillez entrer une tâche valide.");
    }

    function btDelete(){

      const deleteBtn = document.createElement("button");
      deleteBtn.textContent = "Supprimer";
      deleteBtn.id = deleteBtn;
      listItem.appendChild(deleteBtn);
      deleteBtn.addEventListener("click", () => {
        listItem.remove();
      });
   }
      localStorage.setItem(task.concat(i), taskText);
      i++;
}

// OUVRIR LE MENU
function openNav() {
    document.getElementById("mySidebar").style.width = "250px";
    document.getElementById("main").style.marginLeft = "250px";
}
// FERMER LE MENU
function closeNav() {
    document.getElementById("mySidebar").style.width = "0";
    document.getElementById("main").style.marginLeft = "0";
}